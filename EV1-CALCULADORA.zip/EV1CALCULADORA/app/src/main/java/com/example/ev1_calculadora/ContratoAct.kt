package com.example.ev1_calculadora

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ContratoAct : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.act_contrato)

        val editTexto = findViewById<EditText>(R.id.editTexto)
        val verNeto = findViewById<TextView>(R.id.verNeto)
        val botonCalcular = findViewById<Button>(R.id.botonCalcular)

        botonCalcular.setOnClickListener {
            val bPago = editTexto.text.toString().toDoubleOrNull() ?: 0.0
            val nPago = calcularPago(bPago, 0.20)
            verNeto.text = "Pago Neto: $nPago"
        }

        val botonVolver = findViewById<Button>(R.id.botonVolver)
        botonVolver.setOnClickListener {
            finish()
        }
    }

    private fun calcularPago(bruto: Double, retencion: Double=0.20): Double {
        return bruto * (1 - retencion)
    }
}
