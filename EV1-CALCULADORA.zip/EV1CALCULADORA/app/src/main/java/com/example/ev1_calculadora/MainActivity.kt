package com.example.ev1_calculadora

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.act_main)

        val btnHonorario = findViewById<Button>(R.id.btnHonorario)
        val btnContrato = findViewById<Button>(R.id.btnContrato)

        btnHonorario.setOnClickListener {
            startActivity(Intent(this,  HonorariosAct::class.java))
        }

        btnContrato.setOnClickListener {
            startActivity(Intent(this, ContratoAct::class.java))
        }
    }
}
