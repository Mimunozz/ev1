package com.example.ev1_calculadora

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp


class HonorariosAct : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PantallaHonorarios()
        }
    }

    @Composable
    fun PantallaHonorarios() {
        var bPago by remember { mutableStateOf("") }
        val nPago = calcularPago(bPago.toDoubleOrNull() ?: 0.0, 0.13)

        Column(modifier = Modifier.padding(16.dp)) {
            Text("Calculadora de Pagos para Honorarios")

            OutlinedTextField(
                value = bPago,
                onValueChange = { bPago = it },
                label = { Text("Pago Bruto") }
            )

            Text("Pago Neto: $nPago")

            Button(onClick = { finish() }) {
                Text("Volver al Menú Principal")
            }
        }
    }

    private fun calcularPago(bruto: Double, retencion: Double): Double {
        return bruto * (1 - retencion)
    }
}
